#ifndef EMPL_H
#define EMPL_H

typedef struct {
	char name[11];
	int empID;
} Employee;
#endif