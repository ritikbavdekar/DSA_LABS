#include "creditcard.h"
#include "readRecord.h"
#include "insertionSort.h"
void timeForReading();
void timeForSorting();
void spaceForSorting();

void timeForReadingTest(char* filename,char* targetfile);
void timeForSortingTest(char* filename,char* targetfile);
void spaceForSortingTest(char* filename,char* targetfile);
