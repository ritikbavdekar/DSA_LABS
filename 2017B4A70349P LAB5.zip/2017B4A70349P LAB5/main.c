#include "measureTimeAndSpace.h"
#include "insertionSort.h"
#include "readRecord.h"

int main(){
	spaceForSorting();
	timeForReading();
	timeForSorting();
}