#include "creditcard.h"
void insertInOrder(creditCard* cardArray, int n, creditCard newcard);
void insertionSort(creditCard* cardArray,int n);
int *topstack;
