#include "creditcard.h"

creditCard* readCard(creditCard* cardArray,char* filename,int* finalsize);