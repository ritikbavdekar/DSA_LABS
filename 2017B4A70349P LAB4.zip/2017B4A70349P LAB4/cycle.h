#include <stdio.h>
#include <stdbool.h>
bool testcyclic(struct linkedlist* ll);