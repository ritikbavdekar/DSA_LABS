
Procedure for compilation:
gcc -o fileexecutable_name finaltest.c linkedlist.h linkedlist.c memoryalloc.c memoryalloc.h create.h create.c cycle.h [cycle1.c or cycle2.c]

cycle1.c -Hare Tortoise Algorithm
cycle2.c - Link Reversal Algorithm

To change number of elements change in #define No_of_elements in finaltest.c 
