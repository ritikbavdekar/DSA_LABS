#include <stdio.h>
#include "linkedlist.h"
struct linkedlist* createList(int n);
struct linkedlist* createCycle(struct linkedlist* ll);