/***********file:   seqListOps.h *********/
#include "storage.h"

extern int inputJobs(JobList list);
extern void printJobList(JobList list, int size );
extern int initialize_elements(JobList ele);
extern void assignmentSort(JobList list,int size);


