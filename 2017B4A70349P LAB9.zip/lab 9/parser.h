#include <stdio.h>
#include <stdlib.h>

char** parse(char* filename,int count);
int get_size(char* filename);