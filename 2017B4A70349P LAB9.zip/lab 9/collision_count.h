#include <stdio.h>
#include "hash.h"
#include "parser.h"

int collision(char** elements,int baseNumber,int tableSize,int size);