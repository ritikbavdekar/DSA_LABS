#include <stdio.h>

int hash_function(char* element,int baseNumber,int tableSize);

int sum_ascii(char* element);